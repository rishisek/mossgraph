/* 
#include "StickerSheet.h"
#include "Image.h"


StickerSheet::StickerSheet(const Image &picture, unsigned max){
    base_ = picture;
    max_Images = max;


}
StickerSheet::StickerSheet (const StickerSheet &other){

}
const StickerSheet & StickerSheet::operator = (const StickerSheet & other){

}
void StickerSheet::changeMaxStickers (unsigned max){

}
int StickerSheet::addSticker(Image &sticker, int x, int y){
    }
}
int StickerSheet::setStickerAtLayer (Image &sticker, unsigned layer, int x, int y){

}
bool StickerSheet::translate (unsigned index, int x, int y){

}
void StickerSheet::removeSticker (unsigned index){

}
Image * StickerSheet::getSticker(unsigned index){

}
int StickerSheet::layers() const {

}
Image StickerSheet::render() const{

}
*/
